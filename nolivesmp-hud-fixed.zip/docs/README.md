# NoLiveSMP HUD Resource Pack Starter

## 1) Voeg je HUD texture toe
Plaats een PNG op:
`assets/minecraft/textures/font/mana_hud.png`

Eisen voor deze starter:
- Exact 8x8 pixels (1 glyph)
- Transparante achtergrond

## 2) Pack zippen
Ga naar de map boven `nolivesmp-hud` en run:

```bash
cd "/Users/sylvian/nolivesmp-server/resourcepack"
zip -r nolivesmp-hud.zip nolivesmp-hud
```

## 3) Upload + link in Paper
Upload `nolivesmp-hud.zip` naar een directe download URL (Dropbox direct link, GitHub release asset, webhost).

Zet daarna in `server.properties`:

```properties
resource-pack=https://JOUW-DIRECTE-LINK/nolivesmp-hud.zip
resource-pack-prompt=NoLiveSMP gebruikt een custom HUD resourcepack.
require-resource-pack=false
```

## 4) Gebruik van het HUD symbool in tekst
De glyph character is `\uE100`.

Voorbeeld in plugin/scoreboard/actionbar tekst:
- Java string: `"\uE100 Mana: 80/100"`

## 5) Belangrijk
Een echt vrij verplaatsbare HUD-positie kan niet puur vanilla.
Je kunt wel visueel sturen met bossbar/actionbar/scoreboard + custom font glyphs.
